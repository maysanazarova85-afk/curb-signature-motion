import { NightMapPlayer } from './night-map-player.js?v=night-map-4';
// A scroll-selected player for the offline software-rendered 3D assets.
// One visible image, no animation loop, and at most eight decoded-frame owners.
const FRAME_CACHE_LIMIT = 8;
const PREFETCH_RADIUS = 3;
const LOAD_TIMEOUT_MS = 15000;
const clamp = value => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));

class SoftwarePlayer {
  constructor(kind, onFrameReady) {
    this.kind = kind;
    this.onFrameReady = onFrameReady;
    this.base = new URL(`./assets/cinema/v3/${kind}`, import.meta.url).href;
    this.query = kind === 'chair' ? '?v=chair-6-final' : '';
    this.count = 72;
    this.width = 1;
    this.height = 1;
    this.cache = new Map();
    this.mount = null;
    this.image = null;
    this.frame = -1;
    this.requested = 0;
    this.progress = 0;
    this.visible = false;
    this.requestVersion = 0;
    this.fade = null;
    this.underlay = null;
    this.ready = this.initialize();
    // Root can still await the original rejection; this only prevents an early
    // unhandled-rejection report while the three players initialize in parallel.
    this.ready.catch(() => {});
  }

  async initialize() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), LOAD_TIMEOUT_MS);
    let manifest;
    try {
      const response = await fetch(`${this.base}/manifest.json${this.query}`, {signal: controller.signal});
      if (!response.ok) throw new Error(`${this.kind} manifest: HTTP ${response.status}`);
      manifest = await response.json();
    } finally {
      clearTimeout(timer);
    }
    if (!Number.isInteger(manifest.count) || manifest.count < 1 ||
        !Number.isFinite(manifest.width) || manifest.width < 1 ||
        !Number.isFinite(manifest.height) || manifest.height < 1) {
      throw new Error(`Invalid ${this.kind} frame manifest`);
    }
    this.count = manifest.count;
    this.width = manifest.width;
    this.height = manifest.height;
    const first = await this.loadFrame(0, true);
    // Preparing the first decoded frame never starts an offscreen render loop.
    this.image = first.image;
    this.frame = 0;
    this.image.dataset.frame = '0';
    if (this.mount) this.mount.dataset.ready = 'true';
    return this;
  }

  createImage() {
    const image = new Image();
    image.className = 'software-frame';
    image.alt = '';
    image.draggable = false;
    image.decoding = 'async';
    image.inert = true;
    image.setAttribute('aria-hidden', 'true');
    image.width = this.width;
    image.height = this.height;
    Object.assign(image.style, {
      display: 'block', width: '100%', height: '100%',
      objectFit: 'contain', pointerEvents: 'none', userSelect: 'none'
    });
    return image;
  }

  loadFrame(index, important = false) {
    const existing = this.cache.get(index);
    if (existing) {
      existing.used = performance.now();
      if (important) existing.image.fetchPriority = 'high';
      return existing.promise;
    }
    const image = this.createImage();
    image.fetchPriority = important ? 'high' : 'low';
    const entry = {image, index, used: performance.now(), complete: false, cancel: null, promise: null};
    let settle;
    const request = new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        image.onload = image.onerror = null;
        if (error) reject(error);
        else { entry.complete = true; resolve(entry); }
      };
      settle = finish;
      const timer = setTimeout(() => finish(new Error(`${this.kind} frame ${index} timed out`)), LOAD_TIMEOUT_MS);
      image.onload = async () => {
        try {
          if (image.decode) await image.decode();
          finish();
        } catch (error) { finish(error); }
      };
      image.onerror = () => finish(new Error(`${this.kind} frame ${index} unavailable`));
    });
    entry.cancel = () => {
      settle(new Error(`${this.kind} frame ${index} released`));
      // Clearing an attribute releases the offscreen image without requesting
      // the current document as an empty-string URL would do.
      if (image !== this.image) image.removeAttribute('src');
    };
    entry.promise = request.catch(error => {
      if (this.cache.get(index) === entry) this.cache.delete(index);
      throw error;
    });
    this.cache.set(index, entry);
    this.trimCache();
    image.src = `${this.base}/${String(index).padStart(3, '0')}.webp${this.query}`;
    return entry.promise;
  }

  trimCache(hidden = false) {
    if (hidden) {
      for (const [index, entry] of this.cache) {
        // Keep already decoded neighbors for a quick reverse into this scene.
        // Only unfinished offscreen work is canceled; the eight-entry cap stays.
        if (index === this.frame || index === 0 || entry.complete) continue;
        this.cache.delete(index);
        entry.cancel();
      }
      return;
    }
    while (this.cache.size > FRAME_CACHE_LIMIT) {
      let victim;
      let score = -Infinity;
      for (const [index, entry] of this.cache) {
        if (index === this.frame || index === this.requested || entry.image === this.underlay) continue;
        const candidate = Math.abs(index - this.requested) * 100000 + (performance.now() - entry.used);
        if (candidate > score) { score = candidate; victim = entry; }
      }
      if (!victim) break;
      this.cache.delete(victim.index);
      victim.cancel();
    }
  }

  prefetch(index) {
    if (!this.visible) return;
    // Near frames only. HTTP's compressed cache supplies later reverse scrolls;
    // there is deliberately no idle decode of an entire 72-frame sequence.
    for (let distance = 1; distance <= PREFETCH_RADIUS; distance++) {
      for (const neighbor of [index + distance, index - distance]) {
        if (neighbor < 0 || neighbor >= this.count) continue;
        this.loadFrame(neighbor).catch(() => {});
      }
    }
  }

  clearFade() {
    this.fade?.cancel();
    this.fade = null;
    this.underlay?.remove();
    this.underlay = null;
  }

  replaceFrame(previous, mount) {
    this.clearFade();
    if (this.kind !== 'chair' || previous?.parentElement !== mount || typeof this.image.animate !== 'function') {
      if (previous?.parentElement === mount) previous.replaceWith(this.image);
      else mount.append(this.image);
      return;
    }
    // A brief compositor handoff softens a view change; at rest only the
    // original crisp photograph remains. No scroll delay or page RAF is added.
    this.underlay = previous;
    for (const image of [previous, this.image]) Object.assign(image.style, {position: 'absolute', inset: '0'});
    mount.append(this.image);
    const fade = this.image.animate([{opacity: 0}, {opacity: 1}], {duration: 60, easing: 'linear'});
    this.fade = fade;
    fade.finished.catch(() => {}).then(() => {
      if (this.fade !== fade) return;
      previous.remove();
      this.fade = null;
      this.underlay = null;
      this.trimCache();
    });
  }

  async show(mount, progress) {
    if (!(mount instanceof Element)) return;
    const nextProgress = clamp(progress);
    const nextFrame = Math.round(nextProgress * (this.count - 1));
    if (this.visible && this.mount === mount && this.requested === nextFrame &&
        (this.frame === nextFrame || (this.cache.has(nextFrame) && !mount.dataset.error))) {
      // Scroll events often map to the same picture. Preserve its live request
      // instead of repeating styles, prefetch lookups and promise continuations.
      this.progress = nextProgress;
      mount.dataset.progress = this.progress.toFixed(4);
      return;
    }
    if (this.mount && this.mount !== mount) { this.clearFade(); this.mount.dataset.active = 'false'; }
    this.mount = mount;
    this.visible = true;
    this.progress = clamp(progress);
    this.requested = Math.round(this.progress * (this.count - 1));
    const version = ++this.requestVersion;
    mount.setAttribute('aria-hidden', 'true');
    mount.inert = true;
    mount.dataset.active = 'true';
    mount.dataset.progress = this.progress.toFixed(4);
    mount.dataset.requestedFrame = String(this.requested);
    mount.dataset.scene = this.kind;
    if (this.image) {
      this.image.hidden = false;
      this.image.style.display = 'block';
      if (this.image.parentElement !== mount) mount.append(this.image);
      mount.dataset.frame = String(this.frame);
    }
    try {
      await this.ready;
      if (!this.visible || version !== this.requestVersion || mount !== this.mount) return;
      this.requested = Math.round(this.progress * (this.count - 1));
      mount.dataset.requestedFrame = String(this.requested);
      mount.dataset.ready = 'true';
      // A first show can arrive before initialize() finishes. Put its decoded
      // frame0 in place while a different target loads, rather than leaving
      // the decorative viewport empty during that first target request.
      if (this.image && this.image.parentElement !== mount) {
        this.image.hidden = false;
        this.image.style.display = 'block';
        mount.append(this.image);
        mount.dataset.frame = String(this.frame);
      }
      const target = this.requested;
      if (this.frame === target && this.image) {
        this.image.hidden = false;
        this.image.style.display = 'block';
        if (this.image.parentElement !== mount) mount.append(this.image);
        mount.dataset.frame = String(target);
        this.prefetch(target);
        return;
      }
      const loading = this.loadFrame(target, true);
      // Prepare the chair's next angles while this angle decodes, so its
      // denser rotation does not serialize loading behind each image swap.
      if (this.kind === 'chair') this.prefetch(target);
      const entry = await loading;
      if (!this.visible || version !== this.requestVersion || mount !== this.mount || target !== this.requested) return;
      const previous = this.image;
      this.image = entry.image;
      this.frame = target;
      this.image.hidden = false;
      this.image.style.display = 'block';
      // Swap an already-decoded Image into the same decorative mount. The old
      // frame stays visible until this exact point, even during a fast scrub.
      this.replaceFrame(previous, mount);
      this.image.dataset.frame = String(target);
      mount.dataset.frame = String(target);
      delete mount.dataset.error;
      this.trimCache();
      if (this.kind !== 'chair') this.prefetch(target);
      if (typeof this.onFrameReady === 'function') {
        this.onFrameReady({kind: this.kind, frame: target, progress: this.progress, mount});
      }
    } catch (error) {
      if (version !== this.requestVersion || !this.visible) return;
      mount.dataset.error = 'frame-unavailable';
      // Existing decoded content remains in place; root may choose its static
      // section fallback when initial readiness rejects.
    }
  }

  hide() {
    if (!this.visible) return;
    this.visible = false;
    this.requestVersion++;
    this.clearFade();
    if (this.image) { this.image.hidden = true; this.image.style.display = 'none'; }
    if (this.mount) this.mount.dataset.active = 'false';
    this.trimCache(true);
  }
}

export async function createSoftwarePlayers({onFrameReady} = {}) {
  return Object.fromEntries(['pole', 'map', 'chair'].map(kind => [kind, kind === 'map' ? new NightMapPlayer(onFrameReady) : new SoftwarePlayer(kind, onFrameReady)]));
}
