// One sharp city image, decoded once. Scroll moves it continuously rather than
// waiting for numbered pictures. The old lift/fold/approach phase timings remain.
const clamp = value => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));
const ease = value => { const p = clamp(value); return p * p * (3 - 2 * p); };

export function mapPose(progress) {
  const p = clamp(progress);
  const lift = ease((p - .06) / .54);
  const fold = Math.sin(Math.PI * ease((p - .03) / .75)) * .24;
  const approach = ease((p - .56) / .31);
  return {
    x: -6 + approach * 8,
    y: 16 - lift * 21 - approach,
    tilt: 9 * (1 - lift) + fold * 6,
    turn: (-.02 - .14 * lift) * 180 / Math.PI,
    scale: .9 + lift * .025 + approach * .095
  };
}

export function transformForMap(progress) {
  const pose = mapPose(progress);
  const n = value => Number(value.toFixed(6));
  return `perspective(1200px) translate3d(${n(pose.x)}px,${n(pose.y)}px,0) rotateX(${n(pose.tilt)}deg) rotateY(${n(pose.turn)}deg) scale(${n(pose.scale)})`;
}

export class NightMapPlayer {
  constructor(onFrameReady) {
    this.kind = 'map';
    this.onFrameReady = onFrameReady;
    this.mount = null;
    this.progress = 0;
    this.loaded = false;
    this.visible = false;
    this.lastProgress = null;
    this.driver = typeof CSS !== 'undefined' &&
      CSS.supports('view-timeline-name: --curb-night-map') &&
      CSS.supports('animation-timeline: --curb-night-map') &&
      CSS.supports('animation-range: contain 0% contain 100%') ? 'native' : 'raf';

    this.stage = document.createElement('div');
    this.stage.className = 'night-map-stage';
    this.stage.hidden = true;
    this.stage.setAttribute('aria-hidden', 'true');
    this.stage.inert = true;
    this.world = document.createElement('div');
    this.world.className = 'night-map-world';
    this.image = new Image(1536, 1024);
    this.image.className = 'night-map-photo';
    this.image.alt = '';
    this.image.draggable = false;
    this.image.decoding = 'async';
    this.image.fetchPriority = 'low';
    this.image.setAttribute('aria-hidden', 'true');
    this.image.inert = true;
    this.world.append(this.image);
    this.stage.append(this.world);

    this.ready = new Promise((resolve, reject) => {
      let settled = false;
      const finish = error => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        this.image.onload = this.image.onerror = null;
        if (error) { reject(error); return; }
        this.loaded = true;
        if (this.mount) this.mount.dataset.ready = 'true';
        resolve(this);
        if (typeof this.onFrameReady === 'function') {
          this.onFrameReady({kind: 'map', frame: 0, progress: this.progress, mount: this.mount});
        }
      };
      const timer = setTimeout(() => finish(new Error('Night map image timed out')), 15000);
      this.image.onload = async () => {
        try {
          if (this.image.decode) await this.image.decode();
          finish();
        } catch (error) { finish(error); }
      };
      this.image.onerror = () => finish(new Error('Night map image unavailable'));
      this.image.src = new URL('./assets/cinema/night-map/city-night.webp', import.meta.url).href;
    });
    this.ready.catch(() => {});
  }

  show(mount, progress) {
    if (!(mount instanceof Element)) return;
    if (this.mount && this.mount !== mount) this.mount.dataset.active = 'false';
    this.mount = mount;
    this.visible = true;
    this.progress = clamp(progress);
    mount.setAttribute('aria-hidden', 'true');
    mount.inert = true;
    mount.dataset.active = 'true';
    mount.dataset.scene = 'map';
    mount.dataset.driver = this.driver;
    mount.dataset.progress = this.progress.toFixed(4);
    mount.dataset.frame = 'continuous';
    if (this.loaded) mount.dataset.ready = 'true';
    if (this.stage.parentElement !== mount) mount.append(this.stage);
    this.stage.hidden = false;
    if (this.driver === 'raf' && this.progress !== this.lastProgress) {
      this.world.style.transform = transformForMap(this.progress);
    }
    this.lastProgress = this.progress;
  }

  hide() {
    if (!this.visible) return;
    this.visible = false;
    this.stage.hidden = true;
    if (this.mount) this.mount.dataset.active = 'false';
  }
}
