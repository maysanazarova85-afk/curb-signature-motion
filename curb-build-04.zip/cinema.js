// Five authored scroll scenes. Custom software-rendered 3D frames; no WebGL runtime.
const clamp = (n, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const ease = n => { n = clamp(n); return n * n * (3 - 2 * n); };
const phase = (p, a, b) => clamp((p - a) / (b - a));
const el = (tag, className, html = '') => {
  const node = document.createElement(tag); node.className = className;
  node.innerHTML = html; return node;
};
const decorative = node => { node.setAttribute('aria-hidden', 'true'); node.inert = true; return node; };

export function createCinema({ requestRender, refresh }) {
  const hero = document.querySelector('.hero');
  const about = document.querySelector('.about');
  const services = document.querySelector('.essentials');
  const location = document.querySelector('.location');
  const closing = document.querySelector('.closing');
  if (!hero || !about || !services || !location || !closing) return null;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const fine = matchMedia('(hover: hover) and (pointer: fine)');
  const chapters = [];
  let players, assetPromise, assetsReady = false;
  let active = false;
  let openingWidth = 0;
  let cardBoxes = [];

  function chapter(panel, name, travel, minWidth = 1000) {
    const wrap = el('div', `cinema-section ${name}-cinema`);
    panel.before(wrap); wrap.append(panel); panel.classList.add('cinema-panel');
    const item = { name, panel, wrap, travel, minWidth, enabled: false, top: 0, distance: 0, progress: null, height: 0, panelHeight: 0, selection: null };
    chapters.push(item); return item;
  }
  const openingPanel = el('div', 'opening-panel');
  hero.before(openingPanel); openingPanel.append(hero, about);
  const opening = chapter(openingPanel, 'opening', 2.8);
  const service = chapter(services, 'carve', 2, 1200);
  const map = chapter(location, 'fold', 1.4);
  const finale = chapter(closing, 'chair', 1.2);

  // The source hero becomes two rigid, inert decorative panels during the cut.
  const cutCopies = ['upper', 'lower'].map(side => {
    const layer = decorative(el('div', `cut-layer cut-${side}`));
    const copy = hero.cloneNode(true);
    copy.classList.add('cut-surface'); copy.removeAttribute('aria-labelledby');
    copy.querySelectorAll('[id]').forEach(n => n.removeAttribute('id'));
    copy.querySelectorAll('a,button').forEach(n => n.setAttribute('tabindex', '-1'));
    layer.append(copy); openingPanel.append(layer); return layer;
  });
  const seam = decorative(el('div', 'cut-seam'));
  openingPanel.append(seam);
  // Separate rigid blade/handle components share the source photo's actual pivot.
  const scissors = decorative(el('div', 'cut-scissors', `<svg viewBox="0 0 1024 1536" xmlns="http://www.w3.org/2000/svg"><defs><clipPath id="scissor-part-a"><path d="M365 0H640V770L535 900 540 1010 675 1120 670 1390H290V1010L475 970 490 830 440 540Z"/></clipPath><clipPath id="scissor-part-b"><path d="M240 40 370 30 495 485 580 625 680 950 1024 1050V1536H640L640 1170 560 1040 475 790 420 530Z"/></clipPath></defs><g class="scissor-half scissor-half-a" style="transform-origin:531px 642px"><image href="./assets/hero-scissors.webp" width="1024" height="1536" clip-path="url(#scissor-part-a)"/></g><g class="scissor-half scissor-half-b" style="transform-origin:531px 642px"><image href="./assets/hero-scissors.webp" width="1024" height="1536" clip-path="url(#scissor-part-b)"/></g><circle cx="531" cy="642" r="20" fill="#d9d9d2" stroke="#555" stroke-width="8"/><path d="M520 649 542 635" stroke="#444" stroke-width="5"/></svg>`));
  openingPanel.append(scissors);
  const scissorHalves = [scissors.querySelector('.scissor-half-a'), scissors.querySelector('.scissor-half-b')];
  const poleBackdrop = decorative(el('div', 'pole-backdrop'));
  const poleMount = decorative(el('div', 'gpu-mount pole-mount'));
  openingPanel.append(poleBackdrop, poleMount);

  const cards = [...services.querySelectorAll('.service-card')];
  const covers = cards.map((card, index) => {
    const cover = decorative(el('div', 'carve-cover', `<span>${String(index + 1).padStart(2, '0')}</span>`));
    for (let n = 0; n < 9; n++) {
      const fragment = el('i', 'carve-fragment');
      fragment.style.setProperty('--fragment-x', `${8 + n * 10}%`);
      fragment.style.setProperty('--fragment-turn', `${(n % 2 ? -1 : 1) * (22 + n * 13)}deg`);
      card.append(decorative(fragment));
    }
    card.append(cover); return cover;
  });
  const clipper = decorative(el('div', 'carving-clipper', '<img src="./assets/hero-clipper.webp" alt="" width="1024" height="1536">'));
  services.append(clipper);
  const carveRule = decorative(el('div', 'carve-progress'));
  services.append(carveRule);

  const mapBox = location.querySelector('.map-placeholder');
  const mapMount = decorative(el('div', 'gpu-mount map-mount'));
  mapBox.append(mapMount);
  const chairMount = decorative(el('div', 'gpu-mount chair-mount'));
  closing.append(chairMount);
  const closingTitle = closing.querySelector('h2');
  closingTitle.innerHTML = '<span class="seat-line seat-line-a">TAKE A</span> <span class="seat-line seat-line-b">SEAT<span class="lime">.</span></span>';

  async function ensureSoftware() {
    if (assetPromise || !active || reduce.matches) return;
    assetPromise = (async () => {
      try {
        const { createSoftwarePlayers } = await import('./software-player.js?v=chair-6');
        // Decoded images replace themselves at fixed dimensions. Initial readiness
        // already refreshes geometry; each later image swap needs no page render.
        players = await createSoftwarePlayers();
        await Promise.all(Object.values(players).map(player => player.ready));
        assetsReady = true; document.body.classList.add('has-cinema-3d');
        refresh();
      } catch (error) {
        console.warn('CURB: rendered sequence unavailable; content remains accessible.', error.message);
        assetsReady = false; refresh(); hashTarget();
      }
    })();
  }

  function measure() {
    const oldEnabled = active;
    active = fine.matches && !reduce.matches && innerWidth >= 1000 && innerHeight > 700;
    for (const c of chapters) {
      c.wrap.classList.remove('cinema-pinned');
      c.wrap.style.removeProperty('--cinema-height');
      c.wrap.style.removeProperty('--cinema-travel');
      c.enabled = false;
      c.progress = null;
      c.selection = null;
    }
    document.body.classList.toggle('cinema-enabled', active);
    if (!active) {
      if (players) Object.values(players).forEach(player => player.hide());
      resetVisuals();
    }
    for (const c of chapters) {
      let fits = true;
      if (c.name === 'carve' || c.name === 'fold') fits = c.panel.getBoundingClientRect().height <= innerHeight - 12;
      if (c.name === 'opening') fits = about.querySelector('.container').getBoundingClientRect().height <= innerHeight - 130;
      c.enabled = active && innerWidth >= c.minWidth && fits;
      if (c.enabled) {
        c.distance = innerHeight * c.travel;
        c.wrap.style.setProperty('--cinema-height', `${innerHeight}px`);
        c.wrap.style.setProperty('--cinema-travel', `${c.distance}px`);
        c.wrap.classList.add('cinema-pinned');
      } else c.distance = 0;
    }
    // Geometry is read only here, after every pin has its final dimensions.
    for (const c of chapters) {
      const rect = c.wrap.getBoundingClientRect();
      c.top = rect.top + scrollY;
      c.height = rect.height;
      c.panelHeight = c.panel.getBoundingClientRect().height;
    }
    openingWidth = openingPanel.clientWidth;
    cardBoxes = cards.map(card => {
      // Offset geometry ignores the card's temporary entrance translation.
      let x = 0, y = 0, node = card;
      while (node && node !== services) {
        x += node.offsetLeft;
        y += node.offsetTop;
        node = node.offsetParent;
      }
      return {x, y, width: card.offsetWidth, height: card.offsetHeight};
    });
    if (!opening.enabled) {
      hero.style.removeProperty('--hero-source-opacity');
      hero.style.removeProperty('pointer-events');
      about.style.removeProperty('--studio-opacity');
      about.style.removeProperty('pointer-events');
    }
    if (!service.enabled) cards.forEach(card => card.style.removeProperty('--card-color'));
    ensureSoftware();
    if (active !== oldEnabled) requestRender();
  }

  function resetVisuals() {
    hero.style.removeProperty('--hero-source-opacity');
    hero.style.removeProperty('pointer-events');
    about.style.removeProperty('--studio-opacity');
    cards.forEach(card => {
      card.style.removeProperty('--carve-cut'); card.style.removeProperty('--card-color');
    });
    mapBox.style.removeProperty('--map-reveal');
  }

  function paintOpening(p) {
    const q = p;
    const cut = phase(q, .08, .33), split = ease(phase(q, .25, .44));
    const sourceOpacity = 1 - ease(phase(q, .07, .13));
    hero.style.setProperty('--hero-source-opacity', sourceOpacity);
    hero.style.pointerEvents = sourceOpacity > .05 ? 'auto' : 'none';
    const studioAlpha = ease(phase(q, .20, .42));
    about.style.setProperty('--studio-opacity', studioAlpha);
    about.style.pointerEvents = q > .36 ? 'auto' : 'none';
    cutCopies.forEach((copy, i) => {
      const sign = i ? 1 : -1;
      copy.style.opacity = q < .07 ? 0 : 1 - ease(phase(q, .42, .49));
      copy.style.transform = `translate3d(${sign * split * 7}%,${sign * split * 115}%,0) rotate(${sign * split * 8}deg)`;
    });
    seam.style.setProperty('--cut-position', `${cut * 100}%`);
    seam.style.opacity = (1 - ease(phase(q, .30, .39))) * ease(phase(q, .07, .12));
    scissors.style.transform = `translate3d(${openingWidth * (-15 + 130 * cut) / 100}px,0,0) rotate(104deg)`;
    scissors.style.opacity = ease(phase(q, .06, .1)) * (1 - ease(phase(q, .31, .37)));
    const blade = (1 - Math.cos(cut * Math.PI * 8)) * 7 - 4.5;
    scissorHalves[0].style.transform = `rotate(${blade}deg)`;
    scissorHalves[1].style.transform = `rotate(${-blade}deg)`;
    const poleAlpha = assetsReady ? ease(phase(q, .42, .48)) * (1 - ease(phase(q, .91, .99))) : 0;
    poleBackdrop.style.opacity = poleAlpha;
    poleMount.style.opacity = poleAlpha;
    return { key: 'pole', mount: poleMount, progress: phase(q, .44, .97), visible: poleAlpha > .001 };
  }

  function paintCarve(p) {
    const duration = .83 / cards.length;
    const units = phase(p, .06, .89) * cards.length;
    const index = Math.min(cards.length - 1, Math.floor(units));
    cards.forEach((card, i) => {
      const local = phase(p, .06 + i * duration, .06 + (i + .82) * duration);
      card.style.setProperty('--carve-cut', `${ease(local) * 100}%`);
      card.style.setProperty('--card-color', '1');
      card.style.setProperty('--carve-hit', local > .94 ? 'auto' : 'none');
      card.style.setProperty('--fragment-progress', local);
      card.style.setProperty('--fragment-opacity', Math.sin(local * Math.PI));
    });
    const raw = clamp(units - index);
    const local = clamp(raw / .82);
    const rect = cardBoxes[index];
    let x = rect.x + rect.width * .5 - 71;
    let y = rect.y + ease(local) * rect.height - 200;
    const handoff = index < cards.length - 1 ? ease(phase(raw, .82, 1)) : 0;
    if (handoff > 0) {
      const next = cardBoxes[index + 1];
      x += (next.x - rect.x) * handoff;
      y += (next.y - rect.y - rect.height) * handoff - Math.sin(handoff * Math.PI) * 90;
    }
    clipper.style.opacity = ease(phase(p, .01, .06)) * (1 - ease(phase(p, .89, .96)));
    const angle = 180 + Math.sin(local * Math.PI) * 5 + Math.sin(handoff * Math.PI) * 35;
    clipper.style.transform = `translate3d(${x}px,${y}px,0) rotate(${angle}deg)`;
    services.style.setProperty('--carve-progress', p);
  }

  function showModel(selection) {
    if (!players || !assetsReady) return;
    for (const [key, player] of Object.entries(players)) {
      if (selection?.visible && selection.key === key) player.show(selection.mount, selection.progress);
      else player.hide();
    }
  }

  function render() {
    if (document.hidden) return;
    let selection;
    const y = scrollY;
    for (const c of chapters) {
      const p = c.enabled ? clamp((y - c.top) / c.distance) : 0;
      const changed = c.progress !== p;
      c.progress = p;
      if (changed) c.wrap.dataset.progress = p.toFixed(4);
      const panelTop = Math.min(Math.max(c.top - y, 0), c.top + c.height - y - c.panelHeight);
      const inView = c.enabled && panelTop + c.panelHeight > 0 && panelTop < innerHeight;
      if (c.name === 'opening' && c.enabled) {
        if (changed) c.selection = paintOpening(p);
        if (inView) selection = c.selection;
      }
      if (c.name === 'carve' && c.enabled && changed) paintCarve(p);
      if (c.name === 'fold') {
        const reveal = c.enabled && assetsReady ? ease(phase(p, .02, .16)) : 0;
        if (changed) mapBox.style.setProperty('--map-reveal', reveal);
        if (inView) selection = { key: 'map', mount: mapMount, progress: p, visible: reveal > .001 };
      }
      if (c.name === 'chair' && c.enabled) {
        if (changed) {
          closing.style.setProperty('--chair-open', ease(phase(p, .02, .35)));
          closing.style.setProperty('--chair-approach', ease(phase(p, .45, 1)));
          chairMount.style.opacity = ease(phase(p, 0, .16));
        }
        if (inView) selection = { key: 'chair', mount: chairMount, progress: p, visible: true };
      }
    }
    showModel(selection);
  }

  // Native anchors target the actual studio's settled beat inside the opening.
  function studioTarget() { return opening.enabled ? opening.top + opening.distance : about.getBoundingClientRect().top + scrollY; }
  document.addEventListener('click', event => {
    const anchor = event.target.closest('a[href]');
    if (!anchor || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const url = new URL(anchor.href, window.location.origin);
    if (url.origin !== window.location.origin || url.pathname !== window.location.pathname || url.hash !== '#about' || !opening.enabled) return;
    event.preventDefault(); history.pushState(null, '', '#about');
    scrollTo({ top: studioTarget(), behavior: reduce.matches ? 'instant' : 'smooth' });
  });
  let initialHashHandled = false;
  function hashTarget() {
    if (!initialHashHandled && window.location.hash === '#about') {
      initialHashHandled = true; scrollTo({ top: studioTarget(), behavior: 'instant' });
    }
  }
  addEventListener('hashchange', () => { if (window.location.hash === '#about') scrollTo({ top: studioTarget(), behavior: 'instant' }); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) requestRender(); });
  return { measure() { measure(); hashTarget(); }, render };
}
