import { createCinema } from './cinema.js?v=chair-6';
// One event-driven scroll owner; native scrolling remains untouched.
const reduce = matchMedia('(prefers-reduced-motion: reduce)');
const fine = matchMedia('(hover: hover) and (pointer: fine)');
const clamp = (n, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const smooth = n => { n = clamp(n); return n * n * (3 - 2 * n); };
const scenes = [];
let frame = 0;
let measuring = false;

function sceneFor(panel, kind, travel) {
  if (!panel) return;
  const wrapper = document.createElement('div');
  wrapper.className = `motion-scene ${kind}-scene`;
  panel.before(wrapper);
  wrapper.append(panel);
  panel.classList.add('motion-panel');
  const scene = { wrapper, panel, kind, travel, enabled: false, top: 0, distance: 0, progress: 0 };
  scenes.push(scene);
  return scene;
}

const hero = document.querySelector('.hero');
const cinematicHome = document.body.dataset.page === 'home';
const heroScene = cinematicHome ? undefined : sceneFor(hero, 'hero', .75);
const essentials = document.querySelector('.essentials');
const serviceScene = cinematicHome ? undefined : sceneFor(essentials, 'service', .8);
const cinema = cinematicHome ? createCinema({ requestRender, refresh: measure }) : null;
const heroTools = hero ? [...hero.querySelectorAll('.hero-tool')] : [];
const knots = hero ? [...hero.querySelectorAll('.thread-knot')] : [];
const highlights = hero ? [...hero.querySelectorAll('.hero-threads > path')].map(path => {
  const copy = path.cloneNode();
  copy.setAttribute('class', 'thread-highlight');
  copy.setAttribute('stroke', '#fff');
  path.parentNode.append(copy);
  return copy;
}) : [];
const cards = essentials ? [...essentials.querySelectorAll('.service-card')] : [];
cards.forEach(card => {
  const image = card.querySelector('.service-image img');
  if (!image) return;
  const color = image.cloneNode();
  color.className = 'service-color';
  color.alt = '';
  color.setAttribute('aria-hidden', 'true');
  image.after(color);
});
if (essentials) {
  const rule = document.createElement('div');
  rule.className = 'service-progress'; rule.setAttribute('aria-hidden', 'true');
  essentials.append(rule);
}

function paintHero(p) {
  // A continuous pulse moves rigid tools out and back, with zero delta at both ends.
  const outward = smooth((p - .25) / .45);
  const returning = smooth((p - .70) / .30);
  const arc = outward * (1 - returning);
  heroTools.forEach((tool, i) => {
    const side = i ? 1 : -1;
    tool.style.setProperty('--move-x', `${side * 52 * arc}px`);
    tool.style.setProperty('--move-y', `${(i ? -26 : 23) * arc}px`);
    tool.style.setProperty('--move-angle', `${side * 8 * arc}deg`);
    tool.style.setProperty('--tool-scale', `${1 + (i ? -.03 : .035) * arc}`);
  });
  const t = clamp(p / .25);
  highlights.forEach((path, i) => {
    path.style.strokeDashoffset = `${1 - clamp(t * 1.18 - i * .035)}`;
    path.style.opacity = `${Math.sin(Math.PI * t) * .9}`;
  });
  knots.forEach(knot => { knot.style.filter = `brightness(${1 + Math.sin(Math.PI * t) * .45})`; });
  heroScene?.wrapper.style.setProperty('--scene-finish', smooth((p - .70) / .3));
}

function paintServices(p) {
  serviceScene?.wrapper.style.setProperty('--service-progress', p);
  cards.forEach((card, i) => {
    const local = clamp(p * 4 - i);
    const emphasis = Math.sin(local * Math.PI);
    card.style.setProperty('--card-color', smooth(local));
    card.style.setProperty('--card-focus', emphasis);
    card.style.setProperty('--card-scale', 1 + emphasis * .04);
  });
}

const approach = document.querySelector('.approach-list');
const standards = approach ? [...approach.querySelectorAll(':scope > div')] : [];
let approachGeometry = null;
let approachProgress = null;
let standardStates = [];
if (approach) {
  const line = document.createElement('i'); line.className = 'approach-progress'; line.setAttribute('aria-hidden', 'true');
  approach.append(line);
}

function render() {
  frame = 0;
  if (document.hidden || measuring) return;
  cinema?.render();
  for (const scene of scenes) {
    const p = scene.enabled ? clamp((scrollY - scene.top) / scene.distance) : 0;
    if (scene.progress !== p) {
      scene.progress = p;
      if (scene.kind === 'hero') paintHero(p);
      else paintServices(p);
    }
  }
  if (approachGeometry && !reduce.matches) {
    const edge = scrollY + innerHeight * .72;
    const p = clamp((edge - approachGeometry.top) / approachGeometry.height);
    if (p !== approachProgress) {
      approach.style.setProperty('--approach-progress', p);
      approachProgress = p;
    }
    standards.forEach((row, index) => {
      const active = approachGeometry.rows[index] < edge;
      if (standardStates[index] === active) return;
      row.style.setProperty('--standard-color', active ? 'var(--accent)' : 'var(--muted)');
      standardStates[index] = active;
    });
  }
}
function requestRender() {
  if (!frame && !document.hidden) frame = requestAnimationFrame(render);
}
function measure() {
  measuring = true;
  for (const scene of scenes) {
    scene.progress = null;
    scene.wrapper.classList.remove('is-pinned');
    scene.wrapper.style.removeProperty('--panel-height');
    scene.wrapper.style.removeProperty('--scene-travel');
  }
  const desktop = fine.matches && !reduce.matches && innerHeight > 700;
  for (const scene of scenes) {
    const natural = scene.panel.getBoundingClientRect().height;
    const minWidth = scene.kind === 'hero' ? 1000 : 1200;
    const available = innerHeight - (scene.kind === 'hero' ? 0 : 24);
    scene.enabled = desktop && innerWidth >= minWidth && natural <= available;
    if (scene.enabled) {
      scene.distance = Math.round(innerHeight * scene.travel);
      const height = scene.kind === 'hero' ? innerHeight : natural;
      scene.wrapper.style.setProperty('--panel-height', `${height}px`);
      scene.wrapper.style.setProperty('--scene-travel', `${scene.distance}px`);
      scene.wrapper.classList.add('is-pinned');
    } else scene.distance = 0;
  }
  for (const scene of scenes) scene.top = scene.wrapper.getBoundingClientRect().top + scrollY;
  cinema?.measure();
  if (approach) {
    const rect = approach.getBoundingClientRect();
    approachGeometry = {top: rect.top + scrollY, height: rect.height,
      rows: standards.map(row => row.getBoundingClientRect().top + scrollY)};
    approachProgress = null;
    standardStates = [];
  }
  measuring = false;
  requestRender();
}

// Ordinary reveals have one observer and play once. HTML is visible without JS.
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const element = entry.target;
      element.classList.remove('is-waiting');
      if (!reduce.matches) element.classList.add('is-visible');
      if (element.matches('.map-placeholder') && !reduce.matches) element.classList.add('map-enter');
      if (element.matches('.closing')) element.classList.add('closing-enter');
      observer.unobserve(element);
    }
  }, { threshold: .08, rootMargin: '0px 0px -20px 0px' });
  const selectors = '.about-grid>h2,.about-copy>p,.studio-facts>div,.team-section .section-heading,.team-card,.essentials .section-heading,.home-services .service-card,.service-menu .service-card,.approach-layout>h2,.approach-list>div,.location .section-heading,.map-placeholder,.contact-details,.review-card,.reviews-disclaimer,.closing,.page-heading,.price-notice,.booking-notice';
  document.querySelectorAll(selectors).forEach(element => {
    element.classList.add('motion-reveal');
    if (element.matches('h2,.page-heading,.closing')) element.classList.add('motion-mask');
    if (element.matches('.team-card,.review-card,.service-menu .service-card')) {
      const siblings = [...element.parentNode.children];
      element.style.setProperty('--reveal-delay', `${(siblings.indexOf(element) % 4) * 100}ms`);
    }
    if (!reduce.matches && element.getBoundingClientRect().top >= innerHeight) element.classList.add('is-waiting');
    observer.observe(element);
  });
}
document.querySelectorAll('.street-map path').forEach(path => { path.setAttribute('pathLength', '1'); path.style.strokeDasharray = '1'; });

const form = document.querySelector('#booking-form');
const summary = document.querySelector('.booking-summary dl');
if (form && summary) {
  summary.classList.add('summary-details');
  form.addEventListener('change', () => {
    if (reduce.matches) return;
    summary.classList.remove('summary-change');
    void summary.offsetWidth;
    summary.classList.add('summary-change');
  });
}

if (hero) {
  const title = hero.querySelector('h1');
  // Keep the exact source words, line break and white/lime hierarchy.
  if (title) title.innerHTML = '<span class="motion-line"><span>SHARP CUTS.</span></span><span class="motion-line"><span>STREET ROOTS.</span></span>';
}
addEventListener('scroll', requestRender, { passive: true });
addEventListener('resize', measure, { passive: true });
addEventListener('pageshow', measure);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { cancelAnimationFrame(frame); frame = 0; }
  else requestRender();
});
fine.addEventListener('change', measure);
reduce.addEventListener('change', () => {
  document.querySelectorAll('.is-waiting').forEach(el => el.classList.remove('is-waiting'));
  measure();
});
measure();
Promise.allSettled([document.fonts.ready, ...heroTools.map(image => image.decode?.())]).then(() => {
  measure();
  if (hero && !reduce.matches && scrollY < 50) {
    hero.classList.add('is-entering');
    setTimeout(() => hero.classList.remove('is-entering'), 900);
  }
});
// Source aspect ratios reserve the lazy images; no offscreen load loop is needed.
